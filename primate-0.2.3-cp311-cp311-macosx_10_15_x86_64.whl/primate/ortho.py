import numpy as np 
import _orthogonalize

## TODO
# def gram_schmidt(V: np.ndarray, num_vectors: int, last_vector: int, n_ortho: int, v: np.ndarray):
#   """
  
#   """
#   _ortho.gram_schmidt(V, len(v), num_vectors, n_ortho, v)
#   return v

# def orthogonalize():
